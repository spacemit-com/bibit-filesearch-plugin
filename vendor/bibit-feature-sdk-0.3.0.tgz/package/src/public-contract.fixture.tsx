import type { ComponentType } from 'react'
import type {
  ConversationContributionProps,
  FeatureModuleV1,
  FeaturePageProps,
  FeatureSettingsProps,
} from './index'

declare const Page: ComponentType<FeaturePageProps>
declare const Settings: ComponentType<FeatureSettingsProps>
declare const Conversation: ComponentType<ConversationContributionProps>

export const featureModuleFixture = {
  sdkApiVersion: 1,
  pages: { home: Page },
  settings: { manage: Settings },
  conversation: { status: Conversation },
  locales: { en: { title: 'Fixture' } },
} satisfies FeatureModuleV1
