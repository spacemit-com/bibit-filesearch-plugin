import type { FeatureManifestV1 } from './manifest'

export const TRUSTED_PLUGIN_SCHEMA_VERSION = 1 as const

export type TrustedPluginContributionKind =
  | 'page'
  | 'settings'
  | 'permission-presenter'

export interface TrustedPluginBundleManifestV1 {
  pluginSchemaVersion: typeof TRUSTED_PLUGIN_SCHEMA_VERSION
  featureManifest: FeatureManifestV1
  entry: string
  styles: readonly string[]
  files: Readonly<Record<string, string>>
}

export interface TrustedPluginSignatureV1 {
  keyId: string
  signature: string
}

export const getTrustedPluginElementTag = (
  featureId: string,
  kind: TrustedPluginContributionKind,
  contributionId: string
) => `bibit-${featureId}-${kind}-${contributionId}`
