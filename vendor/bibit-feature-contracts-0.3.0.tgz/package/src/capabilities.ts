// Built-ins and compatibility aliases; `service:<kebab-id>` is an extensible namespace.
export const FEATURE_HOST_CAPABILITIES = [
  'service:store',
  'service:memory',
  'service:security',
  'external-service:store',
  'external-service:memory',
  'external-service:security',
  'runtime:permission',
  'file:transfer',
  'job:manage',
] as const

export type FeatureServiceCapability = `service:${string}`
export type FeatureHostCapability =
  | FeatureServiceCapability
  | (typeof FEATURE_HOST_CAPABILITIES)[number]

export const EXPERIMENTAL_FEATURE_HOST_CAPABILITIES = [
  'service:store',
  'service:memory',
  'service:security',
  'external-service:store',
  'external-service:memory',
  'external-service:security',
  'file:transfer',
  'job:manage',
] as const satisfies readonly FeatureHostCapability[]
